package utils;

import java.util.Random;
import dataStruct.Bitmap;
/**
 * @version v1.0
 * @ClassName: BitmapUtils
 * @Description: 位示图工具类
 * @Author: ChenQ
 * @Date: 2021/10/8 on 17:09
 */
public class BitmapUtils {
    private Random random = new Random();
    private static BitmapUtils bitmapUtils;
    private BitmapUtils(){

    }

    public static BitmapUtils getBitmapUtils() {
        if (bitmapUtils == null){
            bitmapUtils = new BitmapUtils();
        }
        return bitmapUtils;
    }

    //设置随机位示图
    public void initBitmap(Bitmap bitmap){
        int itmp[] = new int[bitmap.getUnitSize()];
        for (int i=0;i<itmp.length;i++){
            itmp[i] = random.nextInt(46)+210;
            System.out.print(itmp[i]+" ");
        }
        bitmap.setTmp(itmp);
    }
}

